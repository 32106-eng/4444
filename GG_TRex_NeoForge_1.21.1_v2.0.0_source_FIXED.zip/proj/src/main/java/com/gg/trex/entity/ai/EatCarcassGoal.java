package com.gg.trex.entity.ai;

import com.gg.trex.entity.CarcassEntity;
import com.gg.trex.entity.GGDinoEntity;
import java.util.EnumSet;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;

/**
 * "Hunt -> carcass -> walk over and eat" system of the add-on, as a normal AI goal.
 *
 * Phases: WALK (path to a spot at eat distance from the carcass) -> ADJUST (slide the carcass under the mouth
 * when it is too close) -> EAT (eat_in / eat loop, then heal 4 hearts and play eat_out).
 * Any enemy, damage or rider interrupts the meal and leaves the carcass where it is.
 */
public class EatCarcassGoal extends Goal {
    private static final double SEARCH_RANGE = 32.0;
    private static final double MAX_VERTICAL_DIFF = 3.0;
    private static final double ARRIVE_EPS = 0.25;
    private static final double TOO_CLOSE_OFFSET = 0.9;
    private static final double FALLBACK_OFFSET = 2.0;
    private static final int EAT_OUT_TICKS = 30;
    private static final int UNREACHABLE_TICKS = 600;

    private enum Phase { WALK, ADJUST, EAT }

    private final GGDinoEntity dino;
    private CarcassEntity carcass;
    private Phase phase = Phase.WALK;
    private int phaseTicks;
    private int feedLeft;
    private int maxWalkTicks;
    private int repathIn;
    private int stuckLevel;
    private double lastDist;
    private boolean finished;
    private int cooldown = 100;
    private long nextSearch;

    public EatCarcassGoal(GGDinoEntity dino) {
        this.dino = dino;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        if (this.dino.level().isClientSide) {
            return false;
        }
        long now = this.dino.level().getGameTime();
        if (now < this.nextSearch) {
            return false;
        }
        if (this.dino.isVehicle() || this.dino.getTarget() != null || this.dino.getLastHurtByMob() != null
                || this.dino.isInWaterOrBubble() || !this.dino.onGround()) {
            this.nextSearch = now + 20;
            return false;
        }
        AABB area = this.dino.getBoundingBox().inflate(SEARCH_RANGE, MAX_VERTICAL_DIFF + 3.0, SEARCH_RANGE);
        CarcassEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (CarcassEntity candidate : this.dino.level().getEntitiesOfClass(CarcassEntity.class, area)) {
            if (!candidate.canBeClaimedBy(this.dino)
                    || Math.abs(candidate.getY() - this.dino.getY()) > MAX_VERTICAL_DIFF) {
                continue;
            }
            double d = candidate.distanceToSqr(this.dino);
            if (d < bestDist) {
                bestDist = d;
                best = candidate;
            }
        }
        if (best == null) {
            this.nextSearch = now + 20 + this.dino.getRandom().nextInt(10);
            return false;
        }
        this.carcass = best;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (this.finished || this.carcass == null || this.carcass.isRemoved()) {
            return false;
        }
        return !this.dino.isVehicle() && this.dino.getTarget() == null && this.dino.getLastHurtByMob() == null;
    }

    @Override
    public void start() {
        this.phase = Phase.WALK;
        this.phaseTicks = 0;
        this.finished = false;
        this.cooldown = 100;
        this.stuckLevel = 0;
        this.repathIn = 0;
        this.lastDist = this.dino.distanceTo(this.carcass);
        this.maxWalkTicks = 160 + (int) (this.lastDist * 30.0);
        this.carcass.claim(this.dino);
    }

    @Override
    public void stop() {
        if (this.dino.isFeeding()) {
            this.dino.setFeeding(false); // interrupted: the carcass stays where it is
        }
        if (this.carcass != null) {
            this.carcass.release(this.dino);
        }
        this.nextSearch = this.dino.level().getGameTime() + this.cooldown;
        this.carcass = null;
        this.finished = false;
    }

    @Override
    public void tick() {
        if (this.carcass == null) {
            return;
        }
        this.carcass.claim(this.dino);
        double dx = this.carcass.getX() - this.dino.getX();
        double dz = this.carcass.getZ() - this.dino.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        this.phaseTicks++;
        switch (this.phase) {
            case WALK -> this.tickWalk(dist, dx, dz);
            case ADJUST -> this.tickAdjust(dist, dx, dz);
            case EAT -> this.tickEat(dx, dz);
        }
    }

    // ---------------------------------------------------------------------------------------------

    private void tickWalk(double dist, double dx, double dz) {
        double eat = this.dino.eatDistance();
        this.dino.getLookControl().setLookAt(this.carcass, 30.0F, 30.0F);

        if (dist <= eat + ARRIVE_EPS) {
            this.dino.getNavigation().stop();
            if (dist < eat - TOO_CLOSE_OFFSET) {
                this.phase = Phase.ADJUST;
                this.phaseTicks = 0;
            } else {
                this.beginEating();
            }
            return;
        }
        if (this.phaseTicks > this.maxWalkTicks) {
            this.fallbackOrGiveUp(dist, eat);
            return;
        }
        if (--this.repathIn <= 0) {
            this.repathIn = 10;
            double inv = dist > 1.0E-4 ? 1.0 / dist : 0.0;
            // stand point: at eat distance from the carcass, on the dinosaur's side of it
            double tx = this.carcass.getX() - dx * inv * eat;
            double tz = this.carcass.getZ() - dz * inv * eat;
            boolean ok = this.dino.getNavigation().moveTo(tx, this.carcass.getY(), tz, this.dino.carcassWalkSpeed());
            if (!ok) {
                this.fallbackOrGiveUp(dist, eat);
                return;
            }
        }
        if (this.phaseTicks % 24 == 0) {
            if (this.lastDist - dist < 0.4) {
                if (++this.stuckLevel > 6) {
                    this.fallbackOrGiveUp(dist, eat);
                    return;
                }
            } else {
                this.stuckLevel = 0;
            }
            this.lastDist = dist;
        }
    }

    private void fallbackOrGiveUp(double dist, double eat) {
        this.dino.getNavigation().stop();
        if (dist <= eat + FALLBACK_OFFSET && Math.abs(this.carcass.getY() - this.dino.getY()) <= MAX_VERTICAL_DIFF) {
            this.beginEating();
        } else {
            this.carcass.markUnreachable(UNREACHABLE_TICKS);
            this.cooldown = 200;
            this.finished = true;
        }
    }

    private void tickAdjust(double dist, double dx, double dz) {
        double eat = this.dino.eatDistance();
        this.faceCarcass(dx, dz);
        if (Math.abs(dist - eat) < 0.1 || this.phaseTicks > 40) {
            this.beginEating();
            return;
        }
        // slide the carcass away from the dinosaur until it lies under the mouth
        double inv = dist > 1.0E-4 ? 1.0 / dist : 0.0;
        double step = Math.min(0.25, eat - dist);
        double nx = this.carcass.getX() + (dist > 1.0E-4 ? dx * inv : 0.0) * step;
        double nz = this.carcass.getZ() + (dist > 1.0E-4 ? dz * inv : 1.0) * step;
        this.carcass.setPos(nx, this.carcass.getY(), nz);
    }

    private void beginEating() {
        this.phase = Phase.EAT;
        this.phaseTicks = 0;
        this.feedLeft = 126 + this.dino.getRandom().nextInt(51); // 6.3 - 8.8 seconds
        this.dino.getNavigation().stop();
        this.dino.setFeeding(true);
    }

    private void tickEat(double dx, double dz) {
        this.dino.getNavigation().stop();
        this.faceCarcass(dx, dz);
        if (this.phaseTicks % 14 == 0 && this.dino.level() instanceof ServerLevel server) {
            server.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.BEEF)),
                    this.carcass.getX(), this.carcass.getY() + 0.4, this.carcass.getZ(), 6, 0.3, 0.2, 0.3, 0.05);
        }
        if (--this.feedLeft <= 0) {
            this.completeMeal();
        }
    }

    private void completeMeal() {
        this.dino.heal(8.0F); // about 4 hearts
        this.dino.setFeeding(false);
        this.dino.triggerAnim("action", "eat_out");
        this.carcass.startEaten(EAT_OUT_TICKS);
        this.cooldown = 60;
        this.finished = true;
    }

    private void faceCarcass(double dx, double dz) {
        float target = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        float yaw = Mth.approachDegrees(this.dino.getYRot(), target, this.dino.turnSpeed());
        this.dino.setYRot(yaw);
        this.dino.yBodyRot = yaw;
        this.dino.yHeadRot = yaw;
        this.dino.getLookControl().setLookAt(this.carcass.getX(), this.carcass.getY() + 0.3, this.carcass.getZ());
    }
}
