package com.gg.trex.client.renderer;

import com.gg.trex.client.model.CarcassModel;
import com.gg.trex.entity.CarcassEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class CarcassRenderer extends GeoEntityRenderer<CarcassEntity> {
    public CarcassRenderer(EntityRendererProvider.Context context, String name) {
        super(context, new CarcassModel(name));
        this.shadowRadius = 0.6F;
    }

    @Override
    public void preRender(PoseStack poseStack, CarcassEntity animatable, BakedGeoModel model,
            MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick,
            int packedLight, int packedOverlay, int colour) {
        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender, partialTick,
                packedLight, packedOverlay, colour);
        if (animatable.isBaby()) {
            poseStack.scale(0.55F, 0.55F, 0.55F);
        }
    }
}
