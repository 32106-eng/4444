package com.gg.trex.entity;

import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Carcass left behind when a dinosaur kills a cow / pig / sheep / chicken.
 * Dinosaurs walk to it and eat it (see EatCarcassGoal). Rots away after 30 minutes.
 */
public class CarcassEntity extends Entity implements GeoEntity {
    private static final EntityDataAccessor<Boolean> DATA_BABY =
            SynchedEntityData.defineId(CarcassEntity.class, EntityDataSerializers.BOOLEAN);

    /** 30 minutes, same as the Bedrock add-on. */
    public static final int MAX_AGE = 36000;

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private int age;
    private int eatenTicks = -1;
    private UUID killer;
    private UUID claimedBy;
    private long claimExpires;
    private long unreachableUntil;

    public CarcassEntity(EntityType<? extends CarcassEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_BABY, false);
    }

    public boolean isBaby() {
        return this.entityData.get(DATA_BABY);
    }

    public void setBaby(boolean baby) {
        this.entityData.set(DATA_BABY, baby);
    }

    public void setKiller(UUID killer) {
        this.killer = killer;
    }

    // ---------------------------------------------------------------------------------------------
    // claim / eating bookkeeping (server side)
    // ---------------------------------------------------------------------------------------------

    public boolean canBeClaimedBy(GGDinoEntity dino) {
        if (this.isRemoved() || this.eatenTicks >= 0) {
            return false;
        }
        long now = this.level().getGameTime();
        if (now < this.unreachableUntil) {
            return false;
        }
        if (this.claimedBy != null && !this.claimedBy.equals(dino.getUUID()) && now < this.claimExpires) {
            return false;
        }
        if (this.killer != null && !this.killer.equals(dino.getUUID()) && this.level() instanceof ServerLevel server) {
            Entity other = server.getEntity(this.killer);
            if (other instanceof GGDinoEntity hunter && hunter.isAlive() && hunter.distanceToSqr(this) < 24.0 * 24.0) {
                return false;
            }
        }
        return true;
    }

    public void claim(GGDinoEntity dino) {
        this.claimedBy = dino.getUUID();
        this.claimExpires = this.level().getGameTime() + 40L;
    }

    public void release(GGDinoEntity dino) {
        if (dino.getUUID().equals(this.claimedBy)) {
            this.claimedBy = null;
        }
    }

    public void markUnreachable(int ticks) {
        this.unreachableUntil = this.level().getGameTime() + ticks;
    }

    /** The meal is over: remove the carcass after the dinosaur's eat-out animation has played. */
    public void startEaten(int delayTicks) {
        this.eatenTicks = delayTicks;
    }

    public boolean isBeingEaten() {
        return this.eatenTicks >= 0;
    }

    // ---------------------------------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        Vec3 motion = this.getDeltaMovement();
        if (!this.onGround()) {
            motion = motion.add(0.0, -0.04, 0.0);
        } else {
            motion = new Vec3(motion.x * 0.5, 0.0, motion.z * 0.5);
        }
        this.setDeltaMovement(motion);
        if (!this.onGround() || motion.lengthSqr() > 1.0E-6) {
            this.move(MoverType.SELF, motion);
        }

        if (++this.age > MAX_AGE) {
            this.discard();
            return;
        }
        if (this.eatenTicks >= 0 && --this.eatenTicks < 0) {
            if (this.level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.POOF, this.getX(), this.getY() + 0.3, this.getZ(), 12, 0.5, 0.2, 0.5, 0.02);
            }
            this.discard();
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.age = tag.getInt("Age");
        this.setBaby(tag.getBoolean("Baby"));
        if (tag.hasUUID("Killer")) {
            this.killer = tag.getUUID("Killer");
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Age", this.age);
        tag.putBoolean("Baby", this.isBaby());
        if (this.killer != null) {
            tag.putUUID("Killer", this.killer);
        }
    }

    // GeckoLib (no keyframe animations; the buzzing flies are driven procedurally in the model)
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
