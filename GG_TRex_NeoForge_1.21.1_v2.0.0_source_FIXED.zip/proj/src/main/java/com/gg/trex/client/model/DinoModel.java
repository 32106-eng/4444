package com.gg.trex.client.model;

import com.gg.trex.GGTrex;
import com.gg.trex.client.proc.Pose;
import com.gg.trex.client.proc.ProcSet;
import com.gg.trex.entity.GGDinoEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

/**
 * GeckoLib model of a dinosaur. Keyframe animations (roar, eat, attack ...) come from the animation file;
 * the always-on idle breathing, the distance driven walk cycle, head tracking and the saddle visibility are
 * applied here on top of the keyframe pose.
 */
public class DinoModel<T extends GGDinoEntity> extends GeoModel<T> {
    private final ResourceLocation model;
    private final ResourceLocation animation;
    private final ResourceLocation texture;
    private final ProcSet proc;

    public DinoModel(String name, ProcSet proc) {
        this.model = GGTrex.id("geo/" + name + ".geo.json");
        this.animation = GGTrex.id("animations/" + name + ".animation.json");
        this.texture = GGTrex.id("textures/entity/" + name + ".png");
        this.proc = proc;
    }

    @Override
    public ResourceLocation getModelResource(T animatable) {
        return this.model;
    }

    @Override
    public ResourceLocation getTextureResource(T animatable) {
        return this.texture;
    }

    @Override
    public ResourceLocation getAnimationResource(T animatable) {
        return this.animation;
    }

    @Override
    public void setCustomAnimations(T entity, long instanceId, AnimationState<T> state) {
        Pose pose = new Pose(this.getAnimationProcessor());
        float partial = state.getPartialTick();

        // idle / look fade out while the dinosaur is eating (same 0.08 per tick blend as the add-on)
        float idleWeight = 1.0F - Mth.lerp(partial, entity.eatBlendO, entity.eatBlend);

        double life = (entity.tickCount + partial) / 20.0;
        double t = this.proc.idleLoop() > 0.0 ? life % this.proc.idleLoop() : life;
        this.proc.idle().apply(pose, t, idleWeight);

        // walk cycle follows the distance travelled, so the feet never slide
        boolean airborneRider = entity.isVehicle() && !entity.onGround();
        double distance = Mth.lerp((double) partial, entity.procDistO, entity.procDist);
        double speed = Math.min(1.0, entity.walkAnimation.speed(partial));
        this.proc.walk().apply(pose, distance, speed, airborneRider ? 0.0F : 1.0F);

        // head tracking (yaw +-60, pitch +-30), shared between neck and head
        EntityModelData data = state.getData(DataTickets.ENTITY_MODEL_DATA);
        if (data != null) {
            float yaw = Mth.clamp(data.netHeadYaw(), -60.0F, 60.0F) * Mth.DEG_TO_RAD;
            float pitch = Mth.clamp(data.headPitch(), -30.0F, 30.0F) * Mth.DEG_TO_RAD;
            String[] bones = this.proc.lookBones();
            double[] factors = this.proc.lookFactors();
            for (int i = 0; i < bones.length; i++) {
                float f = (float) factors[i];
                pose.addRotRadians(bones[i], pitch * f, yaw * f, 0.0F, idleWeight);
            }
        }

        pose.setHidden("saddle", !entity.isSaddled());
        if (this.proc.hideWhenSaddled() != null) {
            pose.setHidden(this.proc.hideWhenSaddled(), entity.isSaddled());
        }
    }
}
