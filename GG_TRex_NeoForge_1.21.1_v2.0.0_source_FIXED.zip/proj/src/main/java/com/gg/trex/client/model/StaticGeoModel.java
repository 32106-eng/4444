package com.gg.trex.client.model;

import com.gg.trex.GGTrex;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.model.GeoModel;

/** Model without keyframe animations (venom spit, carcasses). */
public class StaticGeoModel<T extends GeoAnimatable> extends GeoModel<T> {
    private final ResourceLocation model;
    private final ResourceLocation texture;

    public StaticGeoModel(String modelName, String texturePath) {
        this.model = GGTrex.id("geo/" + modelName + ".geo.json");
        this.texture = GGTrex.id(texturePath);
    }

    @Override
    public ResourceLocation getModelResource(T animatable) {
        return this.model;
    }

    @Override
    public ResourceLocation getTextureResource(T animatable) {
        return this.texture;
    }

    @Override
    public ResourceLocation getAnimationResource(T animatable) {
        return GGTrex.id("animations/empty.animation.json");
    }
}
