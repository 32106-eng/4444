package com.gg.trex.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;

public class RaptorEntity extends GGDinoEntity {
    public RaptorEntity(EntityType<? extends RaptorEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 36.0)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.40)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.2)
                .add(Attributes.STEP_HEIGHT, 1.0625)
                .add(Attributes.JUMP_STRENGTH, 1.1);
    }

    @Override protected int experienceReward() { return 14; }
    @Override protected double tameChance() { return 0.45; }
    @Override protected float healRaw() { return 4.0F; }
    @Override protected float healCooked() { return 8.0F; }
    @Override protected float seatY() { return 1.15F; }
    @Override protected float seatZ() { return 0.1F; }
    @Override protected double strideBlocks() { return 2.9032; }
    @Override protected double meleeSpeed() { return 1.3; }
    @Override protected double strollSpeed() { return 0.8; }
    @Override protected double temptSpeed() { return 1.2; }
    @Override protected double playerAggroRange() { return 16.0; }
    @Override protected double preyAggroRange() { return 24.0; }
    @Override public double carcassWalkSpeed() { return 0.30; }
    @Override public double eatDistance() { return 2.0; }
    @Override public float turnSpeed() { return 12.0F; }
    @Override protected boolean huntsCows() { return false; }

    @Override protected SoundEvent stepSound() { return SoundEvents.CHICKEN_STEP; }
    @Override protected SoundEvent ambientSound() { return SoundEvents.FOX_AMBIENT; }
    @Override protected SoundEvent hurtSound() { return SoundEvents.FOX_HURT; }
    @Override protected SoundEvent deathSound() { return SoundEvents.FOX_DEATH; }
    @Override protected float pitchMin() { return 0.6F; }
    @Override protected float pitchMax() { return 0.8F; }

    @Override
    protected SoundEvent keyframeSound(String key) {
        return switch (key) {
            case "step" -> SoundEvents.CHICKEN_STEP;
            case "call" -> SoundEvents.FOX_SCREECH;
            case "eat" -> SoundEvents.FOX_EAT;
            default -> null;
        };
    }

    @Override protected int footstepShake() { return 0; }

    @Override
    protected void addCombatGoals() {
        super.addCombatGoals();
        this.goalSelector.addGoal(4, new LeapAtTargetGoal(this, 0.35F));
    }

    @Override
    protected void tryIdleGesture() {
        if (this.random.nextFloat() < 0.0018F) {
            this.gesture("head_tilt", 50);
        }
    }

    @Override
    protected void registerActions(AnimationController<GGDinoEntity> action) {
        action.triggerableAnim("attack", RawAnimation.begin().thenPlay("attack"))
                .triggerableAnim("head_tilt", RawAnimation.begin().thenPlay("head_tilt"))
                .triggerableAnim("eat_out", RawAnimation.begin().thenPlay("eat_out"));
    }
}
